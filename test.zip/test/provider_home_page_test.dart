import 'package:cupertino_ui/cupertino_ui.dart';
import 'package:flutter_localizations/flutter_localizations.dart'
    show GlobalWidgetsLocalizations;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:sanad/core/routes/app_router.dart';
import 'package:sanad/features/provider/Home_Page/widgets/BottomNavigationBarWidget.dart';
import 'package:sanad/features/provider/Home_Page/screens/provider_home_page.dart';
import 'package:sanad/l10n/generated/app_localizations.dart';

void main() {
  testWidgets('provider dashboard route opens the provider home page', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    appRouter.go('/provider/dashboard');
    await tester.pumpWidget(
      ScreenUtilInit(
        designSize: const Size(360, 690),
        builder: (context, child) => MaterialApp.router(
          locale: const Locale('ar'),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          routerConfig: appRouter,
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType(ProviderHomePage), findsOneWidget);
    expect(find.textContaining('طلبات مناسبة لصنعتك'), findsOneWidget);
    expect(tester.takeException(), isNull);

    tester.view.physicalSize = const Size(320, 568);
    await tester.pumpAndSettle();

    expect(find.byType(ProviderHomePage), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('provider account tab opens the provider profile route', (
    tester,
  ) async {
    final router = GoRouter(
      initialLocation: '/provider/dashboard',
      routes: [
        GoRoute(
          path: '/provider/dashboard',
          builder: (context, state) =>
              const Scaffold(bottomNavigationBar: BottomNavigationBarWidget()),
        ),
        GoRoute(
          path: '/provider/profile',
          builder: (context, state) => const Scaffold(
            body: Center(child: Text('Provider profile destination')),
          ),
        ),
      ],
    );
    addTearDown(router.dispose);

    await tester.pumpWidget(
      ScreenUtilInit(
        designSize: const Size(360, 690),
        builder: (context, child) => MaterialApp.router(
          locale: const Locale('ar'),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          routerConfig: router,
        ),
      ),
    );

    await tester.tap(find.byIcon(Icons.person_outline));
    await tester.pumpAndSettle();

    expect(find.text('Provider profile destination'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
