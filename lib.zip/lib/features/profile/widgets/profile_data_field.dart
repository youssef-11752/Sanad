import 'package:material_ui/material_ui.dart';

import '../../../core/app_colors.dart';

/// A profile value field shared by the read-only and edit views.
class ProfileDataField extends StatelessWidget {
  final String label;
  final String value;
  final bool isRtl;
  final bool isEditing;
  final bool canEdit;
  final TextEditingController? controller;
  final IconData? icon;
  final TextInputType keyboardType;
  final FormFieldValidator<String>? validator;
  final String editTooltip;
  final String saveTooltip;
  final String cancelTooltip;
  final VoidCallback? onEdit;
  final VoidCallback? onSave;
  final VoidCallback? onCancel;

  const ProfileDataField({
    super.key,
    required this.label,
    required this.value,
    required this.isRtl,
    this.canEdit = false,
    this.isEditing = false,
    this.controller,
    this.icon,
    this.keyboardType = TextInputType.text,
    this.validator,
    this.editTooltip = 'Edit',
    this.saveTooltip = 'Save',
    this.cancelTooltip = 'Cancel',
    this.onEdit,
    this.onSave,
    this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.colorScheme.primary;
    final direction = isRtl ? TextDirection.rtl : TextDirection.ltr;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label,
          textAlign: isRtl ? TextAlign.right : TextAlign.left,
          textDirection: direction,
          style: TextStyle(
            color: primary,
            fontSize: 11,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 7),
        Container(
          constraints: const BoxConstraints(minHeight: 45),
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: AppColors.coral, width: 0.8),
          ),
          child: Row(
            textDirection: TextDirection.ltr,
            children: [
              if (icon != null) ...[
                const SizedBox(width: 11),
                Icon(icon, color: primary.withValues(alpha: 0.85), size: 16),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Padding(
                  padding: const EdgeInsetsDirectional.only(start: 9, end: 11),
                  child: isEditing
                      ? TextFormField(
                          controller: controller,
                          keyboardType: keyboardType,
                          validator: validator,
                          textDirection: direction,
                          textAlign: isRtl ? TextAlign.right : TextAlign.left,
                          style: TextStyle(
                            color: theme.colorScheme.onSurface,
                            fontSize: 11,
                          ),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.symmetric(vertical: 12),
                          ),
                        )
                      : Text(
                          value,
                          textAlign: isRtl ? TextAlign.right : TextAlign.left,
                          textDirection: direction,
                          style: TextStyle(
                            color: theme.colorScheme.onSurface,
                            fontSize: 11,
                          ),
                        ),
                ),
              ),
              if (canEdit) ...[
                if (isEditing) ...[
                  IconButton(
                    tooltip: saveTooltip,
                    onPressed: onSave,
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints(
                      minWidth: 32,
                      minHeight: 40,
                    ),
                    padding: EdgeInsets.zero,
                    icon: const Icon(Icons.check, size: 17),
                    color: primary,
                  ),
                  IconButton(
                    tooltip: cancelTooltip,
                    onPressed: onCancel,
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints(
                      minWidth: 32,
                      minHeight: 40,
                    ),
                    padding: EdgeInsets.zero,
                    icon: const Icon(Icons.close, size: 17),
                    color: primary,
                  ),
                ] else
                  IconButton(
                    tooltip: editTooltip,
                    onPressed: onEdit,
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints(
                      minWidth: 36,
                      minHeight: 40,
                    ),
                    padding: EdgeInsets.zero,
                    icon: const Icon(Icons.edit_outlined, size: 16),
                    color: primary,
                  ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}
