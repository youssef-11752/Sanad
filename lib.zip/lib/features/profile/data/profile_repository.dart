import 'package:sanad/core/models/profile_data.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

abstract interface class ProfileRepository {
  Future<ProfileData> loadCurrentProfile();

  Future<void> saveCustomerProfile(ProfileData profile);
}

class SupabaseProfileRepository implements ProfileRepository {
  SupabaseProfileRepository({this.client});

  final SupabaseClient? client;

  SupabaseClient get _client => client ?? Supabase.instance.client;

  @override
  Future<ProfileData> loadCurrentProfile() async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw StateError('No signed-in user is available.');
    }

    final row = await _client
        .from('users')
        .select('full_name, phone')
        .eq('id', user.id)
        .maybeSingle();
    if (row == null) {
      throw StateError('The signed-in user profile was not found.');
    }

    final metadata = user.userMetadata ?? const <String, dynamic>{};
    return ProfileData(
      fullName: _firstNonEmpty([
        row['full_name'],
        metadata['full_name'],
        metadata['name'],
        user.email,
      ]),
      phoneNumber: _firstNonEmpty([
        row['phone'],
        user.phone,
        metadata['phone'],
      ]),
      city: _stringValue(metadata['city']),
      district: _stringValue(metadata['region']),
    );
  }

  @override
  Future<void> saveCustomerProfile(ProfileData profile) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw StateError('No signed-in user is available.');
    }

    final fullName = profile.fullName.trim();
    final phone = profile.phoneNumber.trim();
    final row = await _client
        .from('users')
        .update({'full_name': fullName, 'phone': phone})
        .eq('id', user.id)
        .select('id')
        .maybeSingle();
    if (row == null) {
      throw StateError('The signed-in user profile could not be updated.');
    }

    await _client.auth.updateUser(
      UserAttributes(
        data: {
          'full_name': fullName,
          'name': fullName,
          'city': profile.city.trim(),
          'region': profile.district.trim(),
        },
      ),
    );
  }

  String _firstNonEmpty(Iterable<Object?> values) {
    for (final value in values) {
      final string = _stringValue(value);
      if (string.isNotEmpty) return string;
    }
    return '';
  }

  String _stringValue(Object? value) => value is String ? value.trim() : '';
}
