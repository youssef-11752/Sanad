import 'package:material_ui/material_ui.dart';
import 'package:sanad/core/widgets/custom_SnakBar.dart';
import 'package:sanad/features/auth/data/model/user_role.dart';
import 'package:sanad/features/auth/presentation/auth_strings.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Auth {
  final supa = Supabase.instance.client.auth;

  Future<void> signOut() => supa.signOut();

  Future<String?> currentUserRole() => _currentUserRole();

  Future<bool> login({
    required String email,
    required String password,
    required BuildContext context,
    String? expectedRole,
  }) async {
    try {
      await supa.signInWithPassword(email: email, password: password);
      if (!context.mounted) return false;

      if (expectedRole != null) {
        final actualRole = await _currentUserRole();
        if (!context.mounted) return false;
        if (actualRole == null) {
          await supa.signOut();
          if (!context.mounted) return false;
          customSnakbar(
            context,
            AuthStrings.of(context).accountRoleMissing,
            Colors.red,
          );
          return false;
        }
        if (actualRole != AuthRole.normalize(expectedRole)) {
          await supa.signOut();
          if (!context.mounted) return false;
          customSnakbar(
            context,
            AuthStrings.of(context).wrongAccountRole,
            Colors.red,
          );
          return false;
        }
      }

      return true;
    } on AuthException catch (error) {
      if (!context.mounted) return false;
      final strings = AuthStrings.of(context);
      final message = switch (error.code) {
        'invalid_credentials' => strings.incorrectCredentials,
        'email_not_confirmed' => strings.emailNotConfirmed,
        _ => error.message,
      };
      customSnakbar(context, message, Colors.red);
      return false;
    } catch (error) {
      if (!context.mounted) return false;
      customSnakbar(
        context,
        AuthStrings.of(context).genericAuthError,
        Colors.red,
      );
      return false;
    }
  }

  Future<String?> _currentUserRole() async {
    final user = supa.currentUser;
    if (user == null) return null;

    final client = Supabase.instance.client;
    final profile = await client
        .from('users')
        .select('user_type_id')
        .eq('id', user.id)
        .maybeSingle();
    final userTypeId = profile?['user_type_id'];
    if (userTypeId is! num) return null;

    final userType = await client
        .from('user_types')
        .select('name')
        .eq('id', userTypeId)
        .maybeSingle();
    return AuthRole.normalize(userType?['name']);
  }

  Future<bool> signup({
    required String name,
    required String email,
    required String city,
    required String region,
    required String password,
    required BuildContext context,
    String role = 'customer',
  }) async {
    final strings = AuthStrings.of(context);
    if (AuthRole.normalize(role) != 'customer') {
      customSnakbar(context, strings.wrongAccountRole, Colors.red);
      return false;
    }

    try {
      final response = await supa.signUp(
        password: password,
        email: email,
        data: {
          'name': name,
          'full_name': name,
          'city': city,
          'region': region,
          'role': 'customer',
        },
      );
      if (!context.mounted) return false;

      if (response.user != null &&
          (response.user!.identities?.isEmpty ?? false)) {
        customSnakbar(context, strings.emailAlreadyRegistered, Colors.red);
        return false;
      }

      customSnakbar(context, strings.accountCreatedCheckEmail, Colors.green);
      return true;
    } on AuthException catch (error) {
      if (!context.mounted) return false;
      customSnakbar(context, error.message, Colors.red);
      return false;
    } catch (error) {
      if (!context.mounted) return false;
      customSnakbar(context, strings.genericAuthError, Colors.red);
      return false;
    }
  }

  // Send Otp
  Future<bool> sendOtp(String email, BuildContext context) async {
    try {
      await supa.resetPasswordForEmail(email);
      if (!context.mounted) return false;

      customSnakbar(context, AuthStrings.of(context).otpSent, Colors.green);
      return true;
    } on AuthException catch (e) {
      if (!context.mounted) return false;

      customSnakbar(context, e.message, Colors.red);
      return false;
    } catch (e) {
      if (!context.mounted) return false;

      customSnakbar(
        context,
        AuthStrings.of(context).genericAuthError,
        Colors.red,
      );
      return false;
    }
  }

  Future<bool> verifyOtp(String email, String otp, BuildContext context) async {
    try {
      await supa.verifyOTP(email: email, token: otp, type: OtpType.recovery);
      if (!context.mounted) return false;
      return true;
    } on AuthException catch (e) {
      if (!context.mounted) return false;
      customSnakbar(context, e.message, Colors.red);
      return false;
    } catch (e) {
      if (!context.mounted) return false;
      customSnakbar(
        context,
        AuthStrings.of(context).genericAuthError,
        Colors.red,
      );
      return false;
    }
  }

  Future<bool> resetPassword(String newPassword, BuildContext context) async {
    try {
      await supa.updateUser(UserAttributes(password: newPassword));
      await supa.signOut();
      if (!context.mounted) return false;
      customSnakbar(
        context,
        AuthStrings.of(context).passwordUpdated,
        Colors.green,
      );
      return true;
    } on AuthException catch (e) {
      if (!context.mounted) return false;
      customSnakbar(context, e.message, Colors.red);
      return false;
    } catch (e) {
      if (!context.mounted) return false;
      customSnakbar(
        context,
        AuthStrings.of(context).genericAuthError,
        Colors.red,
      );
      return false;
    }
  }
}
