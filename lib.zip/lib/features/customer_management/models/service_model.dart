import 'package:material_ui/material_ui.dart';
import 'package:sanad/l10n/generated/app_localizations.dart';

enum HomeServiceCategory {
  painting,
  appliances,
  plumbing,
  carpentry,
  electrical,
  airConditioning,
}

class ServiceModel {
  final String id;
  final String title;
  final HomeServiceCategory category;
  final IconData icon;

  const ServiceModel({
    required this.id,
    required this.title,
    required this.category,
    required this.icon,
  });

  String localizedTitle(AppLocalizations localizations) => switch (category) {
    HomeServiceCategory.painting => localizations.paintingCategory,
    HomeServiceCategory.appliances => localizations.applianceCategory,
    HomeServiceCategory.plumbing => localizations.plumbingCategory,
    HomeServiceCategory.carpentry => localizations.carpentryCategory,
    HomeServiceCategory.electrical => localizations.electricalCategory,
    HomeServiceCategory.airConditioning =>
      localizations.airConditioningCategory,
  };
}
