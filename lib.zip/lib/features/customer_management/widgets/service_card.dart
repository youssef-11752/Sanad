import 'package:material_ui/material_ui.dart';
import 'package:sanad/core/theme/colors.dart';
import 'package:sanad/features/customer_management/models/service_model.dart';
import 'package:sanad/l10n/generated/app_localizations.dart';

class ServiceCards extends StatelessWidget {
  // list of services displayed in the gridview
  final List<ServiceModel> services;
  final ValueChanged<ServiceModel>? onServiceSelected;

  const ServiceCards({
    super.key,
    required this.services,
    this.onServiceSelected,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true, //take only the height it needs "not entire height of the screen"
      // number of service cards
      itemCount: services.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // 2 cards in each row
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.55,
      ),
      // build each card using its index
      itemBuilder: (context, index) {
        final service = services[index];
        final title = service.localizedTitle(AppLocalizations.of(context)!);
        return Material(
          color: AppThemes.whiteColor,
          borderRadius: BorderRadius.circular(13),
          child: InkWell(
            onTap: onServiceSelected == null
                ? null
                : () => onServiceSelected!(service),
            borderRadius: BorderRadius.circular(13),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: AppThemes.darkCremey),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(service.icon, color: AppThemes.greenColor, size: 24),
                  SizedBox(height: 8),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppThemes.darkGreen,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
