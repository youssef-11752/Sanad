String serviceAddressFromMetadata(
  Map<String, dynamic>? metadata, {
  required String fallback,
}) {
  final region = metadata?['region'];
  final city = metadata?['city'];
  final addressParts = [
    if (region is String && region.trim().isNotEmpty) region.trim(),
    if (city is String && city.trim().isNotEmpty) city.trim(),
  ];

  return addressParts.isEmpty ? fallback : addressParts.join('، ');
}
