import 'package:material_ui/material_ui.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:sanad/core/theme/colors.dart';
import 'package:sanad/features/customer_management/client_home_provider.dart';
import 'package:sanad/features/customer_management/service_address.dart';
import 'package:sanad/features/request_status/models/request_item.dart';
import 'package:sanad/features/request_status/widgets/current_request_card.dart';
import 'package:sanad/features/request_status/widgets/request_status_colors.dart';
import 'package:sanad/features/customer_management/widgets/home_header.dart';
import 'package:sanad/features/customer_management/widgets/provider_card.dart';
import 'package:sanad/features/customer_management/widgets/service_card.dart';
import 'package:sanad/features/main_navigation/widgets/main_bottom_navigation.dart';
import 'package:sanad/l10n/generated/app_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ClientHomeScreen extends StatefulWidget {
  const ClientHomeScreen({
    super.key,
    this.serviceAddress,
    this.currentRequestsFuture,
  });

  final String? serviceAddress;
  final Future<List<RequestItem>>? currentRequestsFuture;

  @override
  State<ClientHomeScreen> createState() => _ClientHomeScreenState();
}

class _ClientHomeScreenState extends State<ClientHomeScreen> {
  String _searchQuery = '';
  late Future<List<RequestItem>> _currentRequestsFuture;

  @override
  void initState() {
    super.initState();
    _currentRequestsFuture =
        widget.currentRequestsFuture ?? _loadCurrentRequests();
  }

  @override
  void didUpdateWidget(covariant ClientHomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.currentRequestsFuture != oldWidget.currentRequestsFuture) {
      _currentRequestsFuture =
          widget.currentRequestsFuture ?? _loadCurrentRequests();
    }
  }

  Future<List<RequestItem>> _loadCurrentRequests() async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) {
      throw StateError('No signed-in user is available.');
    }

    final rows = await client
        .from('issues')
        .select('id, provider_id, title, status, created_at')
        .eq('user_id', user.id)
        .inFilter('status', ['pending', 'accepted', 'in_progress'])
        .order('created_at', ascending: false)
        .limit(3);

    return rows.map(RequestItem.fromIssue).toList();
  }

  void _retryLoadingCurrentRequests() {
    setState(() {
      _currentRequestsFuture = _loadCurrentRequests();
    });
  }

  Widget _buildCurrentRequests(AppLocalizations localizations) {
    return FutureBuilder<List<RequestItem>>(
      future: _currentRequestsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                '${localizations.ordersLoadError}\n${snapshot.error}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: requestMutedColor, fontSize: 13),
              ),
              TextButton(
                onPressed: _retryLoadingCurrentRequests,
                child: Text(localizations.retryButton),
              ),
            ],
          );
        }

        final requests = snapshot.requireData;
        if (requests.isEmpty) {
          return Text(
            localizations.noCurrentOrders,
            style: const TextStyle(color: requestMutedColor, fontSize: 13),
          );
        }

        return Column(
          children: [
            for (final request in requests) ...[
              CurrentRequestCard(
                request: request,
                statusLabel: localizations.pendingStatus,
              ),
              const SizedBox(height: 10),
            ],
          ],
        );
      },
    );
  }

  String _serviceAddress(AppLocalizations localizations) {
    final serviceAddress = widget.serviceAddress;
    if (serviceAddress != null) return serviceAddress;

    final metadata = Supabase.instance.client.auth.currentUser?.userMetadata;
    return serviceAddressFromMetadata(
      metadata,
      fallback: localizations.hintCity,
    );
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    final homeProvider = context.watch<ClientHomeProvider>();
    final normalizedQuery = _searchQuery.trim().toLowerCase();
    final visibleServices = homeProvider.services.where((service) {
      return service
          .localizedTitle(localizations)
          .toLowerCase()
          .contains(normalizedQuery);
    }).toList();

    return Directionality(
      textDirection: Directionality.of(context),
      child: Scaffold(
        backgroundColor: AppThemes.cremeyColor,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                HomeHeader(
                  address: _serviceAddress(localizations),
                  addressTitle: localizations.homeAddressTitle,
                  searchHint: localizations.categoriesSearchHint,
                  onSearchChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  onSearchSubmitted: (value) {
                    final query = value.trim();
                    if (query.isNotEmpty) {
                      context.go(
                        '/customer/categories?q=${Uri.encodeQueryComponent(query)}',
                      );
                    }
                  },
                ),
                SizedBox(height: 17),
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: AppThemes.greenColor,
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Align(
                            alignment: AlignmentDirectional.topStart,
                            child: Text(
                              localizations.homeBannerEyebrow,
                              style: TextStyle(
                                color: AppThemes.privacyColor,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Spacer(),
                          Align(
                            alignment: AlignmentDirectional.topEnd,
                            child: Icon(
                              Icons.home_repair_service_outlined,
                              color: AppThemes.cremeyColor,
                              size: 30,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 5),
                      Align(
                        alignment: AlignmentDirectional.topStart,
                        child: Column(
                          children: [
                            Text(
                              localizations.homeBannerTitle,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                color: AppThemes.whiteColor,
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 7),
                            Text(
                              localizations.homeBannerDescription,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                color: AppThemes.privacyColor,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 13),
                      SizedBox(
                        height: 43,
                        child: ElevatedButton(
                          onPressed: () => context.go('/customer/categories'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppThemes.redColor,
                            foregroundColor: AppThemes.whiteColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9),
                            ),
                          ),
                          child: Text(
                            localizations.homeRequestServiceButton,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),

                Row(
                  children: [
                    Text(
                      localizations.homeServicePrompt,
                      style: TextStyle(
                        color: AppThemes.darkGreen,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => context.go('/customer/requests'),
                      child: Text(
                        localizations.allRequestsLink,
                        style: TextStyle(
                          color: AppThemes.redColor,
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                if (visibleServices.isEmpty)
                  Text(
                    localizations.homeSearchNoResults,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppThemes.hiAccount,
                      fontSize: 12,
                    ),
                  )
                else
                  ServiceCards(
                    services: visibleServices,
                    onServiceSelected: (service) {
                      context.push(
                        '/customer/new-request',
                        extra: service.title,
                      );
                    },
                  ),

                const SizedBox(height: 22),

                Row(
                  children: [
                    Text(
                      localizations.currentOrdersSection,
                      style: TextStyle(
                        color: AppThemes.darkGreen,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => context.go('/customer/requests'),
                      child: Text(
                        localizations.allRequestsLink,
                        style: TextStyle(
                          color: AppThemes.redColor,
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildCurrentRequests(localizations),
                const SizedBox(height: 22),

                Row(
                  children: [
                    Text(
                      localizations.homeRecommendedProviders,
                      style: TextStyle(
                        color: AppThemes.darkGreen,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      localizations.viewAll,
                      style: TextStyle(color: AppThemes.redColor, fontSize: 10),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                ProviderCards(providers: homeProvider.providers),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        bottomNavigationBar: MainBottomNavigation(
          selectedDestination: MainNavigationDestination.home,
        ),
      ),
    );
  }
}
