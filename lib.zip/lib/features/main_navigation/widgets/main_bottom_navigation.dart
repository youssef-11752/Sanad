import 'package:material_ui/material_ui.dart';
import 'package:go_router/go_router.dart';
import 'package:sanad/core/theme/colors.dart';
import 'package:sanad/l10n/generated/app_localizations.dart';

enum MainNavigationDestination { home, categories, requests, account }

class MainBottomNavigation extends StatelessWidget {
  const MainBottomNavigation({
    required this.selectedDestination,
    this.isProvider = false,
    super.key,
  });

  final MainNavigationDestination selectedDestination;
  final bool isProvider;

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    const destinations = MainNavigationDestination.values;
    final labels = [
      localizations.homeNavigation,
      isProvider
          ? localizations.providerServicesNavigation
          : localizations.categoriesNavigation,
      isProvider
          ? localizations.providerOrdersNavigation
          : localizations.myRequestsNavigation,
      localizations.accountNavigation,
    ];
    const icons = [
      Icons.home_outlined,
      Icons.grid_view_outlined,
      Icons.receipt_long_outlined,
      Icons.person_outline,
    ];

    return Container(
      decoration: const BoxDecoration(
        color: AppThemes.whiteColor,
        border: Border(top: BorderSide(color: AppThemes.darkCremey)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            children: [
              for (var index = 0; index < destinations.length; index++)
                Expanded(
                  child: _NavigationItem(
                    icon: icons[index],
                    label: labels[index],
                    isSelected: selectedDestination == destinations[index],
                    onTap: () => _selectDestination(
                      context,
                      destinations[index],
                      localizations,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _selectDestination(
    BuildContext context,
    MainNavigationDestination destination,
    AppLocalizations localizations,
  ) {
    switch (destination) {
      case MainNavigationDestination.home:
        context.go(isProvider ? '/provider/dashboard' : '/customer/management');
        return;
      case MainNavigationDestination.categories:
        if (isProvider) {
          _showComingSoon(context, localizations);
        } else {
          context.go('/customer/categories');
        }
        return;
      case MainNavigationDestination.requests:
        if (isProvider) {
          _showComingSoon(context, localizations);
        } else {
          context.go('/customer/requests');
        }
        return;
      case MainNavigationDestination.account:
        context.go(isProvider ? '/provider/profile' : '/customer/profile');
    }
  }

  void _showComingSoon(BuildContext context, AppLocalizations localizations) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(localizations.navigationComingSoon)));
  }
}

class _NavigationItem extends StatelessWidget {
  const _NavigationItem({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    const selectedColor = AppThemes.greenColor;
    const inactiveColor = AppThemes.hiAccount;
    final color = isSelected ? selectedColor : inactiveColor;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        height: 48,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(height: 2),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: color,
                  fontSize: 10,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                ),
              ),
              if (isSelected)
                Container(
                  margin: const EdgeInsets.only(top: 2),
                  width: 14,
                  height: 2,
                  decoration: BoxDecoration(
                    color: selectedColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
