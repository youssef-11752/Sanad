import 'package:sanad/core/theme/colors.dart';

const requestPageColor = AppThemes.cremeyColor;
const requestCardColor = AppThemes.whiteColor;
const requestTealColor = AppThemes.greenColor;
const requestRedColor = AppThemes.redColor;
const requestBorderColor = AppThemes.darkCremey;
const requestMutedColor = AppThemes.hiAccount;
const requestStatusColor = AppThemes.privacyColor;
