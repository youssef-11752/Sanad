import 'package:material_ui/material_ui.dart';
import 'package:sanad/core/constants/Colors.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      textDirection: TextDirection.rtl,
      children: const [
        Expanded(
          child: _DashboardCard(value: '٤.٩', label: 'تقييمك'),
        ),
        SizedBox(width: 8),
        Expanded(
          child: _DashboardCard(value: '٣', label: 'زيارات الأسبوع'),
        ),
        SizedBox(width: 8),
        Expanded(
          child: _DashboardCard(value: '٢', label: 'طلبات متطابقة'),
        ),
      ],
    );
  }
}

class _DashboardCard extends StatelessWidget {
  const _DashboardCard({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: StoneWhite,
        border: Border.all(width: 2, color: Cream),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(color: Boxshadowcolor, offset: Offset(5, 5), blurRadius: 4),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: TextStyle(
              color: DimGray,
              fontSize: 24,
              fontFamily: 'Cairo',
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 5),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: DimGray,
                fontSize: 13,
                fontFamily: 'Cairo',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
