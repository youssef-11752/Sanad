import 'package:material_ui/material_ui.dart';
import 'package:sanad/features/main_navigation/widgets/main_bottom_navigation.dart';

class BottomNavigationBarWidget extends StatelessWidget {
  const BottomNavigationBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const MainBottomNavigation(
      selectedDestination: MainNavigationDestination.home,
      isProvider: true,
    );
  }
}
