/// Personal details shown in the customer profile.
///
/// Keeping these values together makes it clear which fields are edited and
/// lets every screen render the same saved profile.
class ProfileData {
  final String fullName;
  final String phoneNumber;
  final String city;
  final String district;

  const ProfileData({
    required this.fullName,
    required this.phoneNumber,
    required this.city,
    required this.district,
  });

  static const sample = ProfileData(
    fullName: 'مريم حسن',
    phoneNumber: '01135045965',
    city: 'القاهرة',
    district: 'مدينة نصر',
  );

  String get location =>
      [city, district].where((part) => part.trim().isNotEmpty).join(' • ');

  factory ProfileData.fromLocation({
    required String fullName,
    required String phoneNumber,
    required String location,
  }) {
    final parts = location.split(RegExp(r'[,،•]'));
    return ProfileData(
      fullName: fullName,
      phoneNumber: phoneNumber,
      city: parts.isNotEmpty ? parts.first.trim() : '',
      district: parts.length > 1 ? parts.skip(1).join(' ').trim() : '',
    );
  }

  ProfileData copyWith({
    String? fullName,
    String? phoneNumber,
    String? city,
    String? district,
  }) {
    return ProfileData(
      fullName: fullName ?? this.fullName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      city: city ?? this.city,
      district: district ?? this.district,
    );
  }
}
