import 'package:material_ui/material_ui.dart';
import 'package:sanad/core/constants/Colors.dart';

abstract final class AppThemes {
  static const Color greenColor = DarkTeal;
  static const Color redColor = Rust;
  static const Color cremeyColor = Cream;
  static const Color darkCremey = Champagane;
  static const Color darkGreen = Color(0xFF123F37);
  static const Color mediumGreen = Color(0xFF17483E);
  static const Color whiteColor = SeaShell;
  static const Color privacyColor = StoneWhite;
  static const Color hiAccount = DimGray;
  static const Color splashText = darkGreen;
  static const Color SplashText = splashText;

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: cremeyColor,
    colorScheme: const ColorScheme.light(
      primary: greenColor,
      secondary: redColor,
      surface: whiteColor,
      error: redColor,
      onPrimary: whiteColor,
      onSurface: darkGreen,
    ),
    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: darkGreen),
      bodyMedium: TextStyle(color: darkGreen),
      bodySmall: TextStyle(color: hiAccount),
      titleLarge: TextStyle(color: greenColor),
      titleMedium: TextStyle(color: greenColor),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: cremeyColor,
      foregroundColor: darkGreen,
      elevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: whiteColor,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: const TextStyle(color: hiAccount),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkCremey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: darkCremey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: greenColor, width: 1.5),
      ),
    ),
  );

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: darkGreen,
    colorScheme: const ColorScheme.dark(
      primary: darkCremey,
      secondary: redColor,
      surface: mediumGreen,
      error: redColor,
      onPrimary: darkGreen,
      onSurface: whiteColor,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: darkGreen,
      foregroundColor: whiteColor,
      elevation: 0,
    ),
  );
}
