import 'package:material_ui/material_ui.dart';

enum AppThemeChoice { light, dark, system }

class AppLocaleController {
  AppLocaleController._();

  static final ValueNotifier<Locale> current = ValueNotifier<Locale>(
    const Locale('ar'),
  );

  static void setLocale(Locale locale) {
    if (locale.languageCode != 'ar' && locale.languageCode != 'en') {
      throw ArgumentError.value(
        locale,
        'locale',
        'Only Arabic and English are supported.',
      );
    }
    current.value = Locale(locale.languageCode);
  }
}

class AppThemeController {
  AppThemeController._();

  static final ValueNotifier<AppThemeChoice> current =
      ValueNotifier<AppThemeChoice>(AppThemeChoice.light);

  static void setTheme(AppThemeChoice theme) {
    current.value = theme;
  }
}
