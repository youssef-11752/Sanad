import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:sanad/features/auth/presentation/screens/finish_otp_screen.dart';
import 'package:sanad/features/auth/presentation/screens/forget_password.dart';
import 'package:sanad/features/auth/presentation/screens/login_Provider.dart';
import 'package:sanad/features/auth/presentation/screens/login_User_screen.dart';
import 'package:sanad/features/auth/presentation/screens/new_Password.dart';
import 'package:sanad/features/auth/presentation/screens/otp_screen.dart';
import 'package:sanad/features/auth/presentation/screens/signUp_Screen.dart';
import 'package:sanad/features/auth/presentation/screens/splash_Screen.dart';
import 'package:sanad/features/customer_management/client_home_provider.dart';
import 'package:sanad/features/customer_management/screens/client_home_screen.dart';
import 'package:sanad/features/onboarding/screens/onboarding_screen.dart';
import 'package:sanad/features/profile/provider_profile_screen.dart';
import 'package:sanad/features/profile/user_profile_screen.dart';
import 'package:sanad/features/provider/Home_Page/screens/provider_home_page.dart';
import 'package:sanad/features/request_status/screens/my_requests_screen.dart';
import 'package:sanad/features/request_status/screens/new_request_screen.dart';
import 'package:sanad/features/service_categories/screens/service_categories_screen.dart';
import 'package:sanad/features/type_selection/role_selection_screen.dart';

String _authRoleFromPath(GoRouterState state) {
  final role = state.pathParameters['role'];
  if (role != 'customer' && role != 'provider') {
    throw StateError('Unsupported authentication role: $role');
  }
  return role!;
}

final GoRouter appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(path: '/splash', builder: (context, state) => const SplashScreen()),
    GoRoute(
      path: '/onboarding',
      builder: (context, state) => const OnboardingScreen(),
    ),
    GoRoute(
      path: '/role-selection',
      builder: (context, state) => const RoleSelectionScreen(),
    ),
    GoRoute(
      path: '/login/customer',
      builder: (context, state) => const LoginUserScreen(),
    ),
    GoRoute(
      path: '/loginUser',
      builder: (context, state) => const LoginUserScreen(),
    ),
    GoRoute(
      path: '/login/provider',
      builder: (context, state) => const LoginProvider(),
    ),
    GoRoute(
      path: '/loginProvider',
      builder: (context, state) => const LoginProvider(),
    ),
    GoRoute(path: '/signUp', builder: (context, state) => const SignupScreen()),
    GoRoute(
      path: '/signup/customer',
      builder: (context, state) => const SignupScreen(),
    ),
    GoRoute(
      path: '/forgetPassword',
      builder: (context, state) => const ForgetPassword(role: 'customer'),
    ),
    GoRoute(
      path: '/forgot-password/:role',
      builder: (context, state) =>
          ForgetPassword(role: _authRoleFromPath(state)),
    ),
    GoRoute(
      path: '/otpScreen',
      builder: (context, state) =>
          OtpScreen(email: state.extra as String? ?? '', role: 'customer'),
    ),
    GoRoute(
      path: '/otpScreen/:role',
      builder: (context, state) => OtpScreen(
        email: state.extra as String? ?? '',
        role: _authRoleFromPath(state),
      ),
    ),
    GoRoute(
      path: '/newPassword',
      builder: (context, state) => const NewPassword(),
    ),
    GoRoute(
      path: '/newPassword/:role',
      builder: (context, state) => NewPassword(role: _authRoleFromPath(state)),
    ),
    GoRoute(
      path: '/finishOtp',
      builder: (context, state) => const FinishOtpScreen(),
    ),
    GoRoute(
      path: '/finishOtp/:role',
      builder: (context, state) =>
          FinishOtpScreen(role: _authRoleFromPath(state)),
    ),
    GoRoute(
      path: '/customer/management',
      builder: (context, state) => ChangeNotifierProvider(
        create: (_) => ClientHomeProvider(),
        child: const ClientHomeScreen(),
      ),
    ),
    GoRoute(
      path: '/customer/categories',
      builder: (context, state) => ServiceCategoriesScreen(
        initialSearchQuery: state.uri.queryParameters['q'] ?? '',
      ),
    ),
    GoRoute(
      path: '/customer/requests',
      builder: (context, state) =>
          MyRequestsScreen(key: ValueKey(state.uri.queryParameters['refresh'])),
    ),
    GoRoute(
      path: '/customer/new-request',
      builder: (context, state) =>
          NewRequestScreen(initialCategory: state.extra as String?),
    ),
    GoRoute(
      path: '/customer/profile',
      builder: (context, state) => const UserProfileScreen(),
    ),
    GoRoute(
      path: '/provider/profile',
      builder: (context, state) => const ProviderProfileScreen(),
    ),
    GoRoute(
      path: '/provider/dashboard',
      builder: (context, state) => const ProviderHomePage(),
    ),
  ],
);
