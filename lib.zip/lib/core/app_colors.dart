import 'package:sanad/core/theme/colors.dart';

abstract final class AppColors {
  static const teal = AppThemes.greenColor;
  static const lightTeal = AppThemes.privacyColor;
  static const coral = AppThemes.redColor;
  static const red = AppThemes.redColor;
  static const cream = AppThemes.cremeyColor;
  static const card = AppThemes.whiteColor;
  static const grey = AppThemes.hiAccount;
}
